package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Requirements;
import com.example.demo.repository.RequirementsRepository;

import java.util.List;

@Service
public class RequirementsService {

    @Autowired
    private RequirementsRepository requirementRepository;

    public List<Requirements> getAllRequirements() {
        return requirementRepository.findAll();
    }

    public Requirements getRequirementById(int id) {
        return requirementRepository.findById(id).orElse(null);
    }

    public Requirements saveRequirement(Requirements requirement) {
        return requirementRepository.save(requirement);
    }

    public void deleteRequirement(int id) {
        requirementRepository.deleteById(id);
    }
}
