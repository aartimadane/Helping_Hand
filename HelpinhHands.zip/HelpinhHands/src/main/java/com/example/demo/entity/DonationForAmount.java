package com.example.demo.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Entity
@Table(name = "donationforamount")
public class DonationForAmount {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donation_amt_id")
    private int donationAmtId;

    @Column(name = "amount", nullable = false, precision = 10, scale = 2)
    private BigDecimal amount;

    @Column(name = "date", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp date;
    			
    @ManyToOne
    @JoinColumn(name = "requirement_id")
    private Requirements requirement;

    // Default constructor
    public DonationForAmount() {
    }

    // Parameterized constructor
    public DonationForAmount(BigDecimal amount, Timestamp date, Requirements requirement) {
        this.amount = amount;
        this.date = date;
        this.requirement = requirement;
    }

    // Getters and Setters
    public int getDonationAmtId() {
        return donationAmtId;
    }

    public void setDonationAmtId(int donationAmtId) {
        this.donationAmtId = donationAmtId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public Requirements getRequirement() {
        return requirement;
    }

    public void setRequirement(Requirements requirement) {
        this.requirement = requirement;
    }

    @Override
    public String toString() {
        return "DonationForAmount{" +
                "donationAmtId=" + donationAmtId +
                ", amount=" + amount +
                ", date=" + date +
                ", requirement=" + requirement +
                '}';
    }
}

