package com.example.demo.entity;

import java.util.Objects;
import java.util.Set;

import com.example.demo.entity.User.DonorType;

import com.example.demo.entity.User.UserStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "donor")
public class Donor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donor_id")
    private Integer donorId;

    @Enumerated(EnumType.STRING)
    @Column(name = "donor_type", nullable = false)
    private DonorType donorType;

    @Column(name = "f_name")
    private String firstName;

    @Column(name = "l_name")
    private String lastName;

    @Column(name = "org_name")
    private String organizationName;

    @Column(name = "license_no", nullable = false, unique = true)
    private String licenseNo;

    @Column(name = "contact_no")
    private String contactNo;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "website")
    private String website;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private UserStatus status;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne
    @JoinColumn(name = "u_id")
    private User user;

	public Integer getDonorId() {
		return donorId;
	}

	public void setDonorId(Integer donorId) {
		this.donorId = donorId;
	}

	public DonorType getDonorType() {
		return donorType;
	}

	public void setDonorType(DonorType donorType) {
		this.donorType = donorType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Donor(Integer donorId, DonorType donorType, String firstName, String lastName, String organizationName,
			String licenseNo, String contactNo, String email, String website, UserStatus status, Area area, User user) {
		super();
		this.donorId = donorId;
		this.donorType = donorType;
		this.firstName = firstName;
		this.lastName = lastName;
		this.organizationName = organizationName;
		this.licenseNo = licenseNo;
		this.contactNo = contactNo;
		this.email = email;
		this.website = website;
		this.status = status;
		this.area = area;
		this.user = user;
	}

	public Donor() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Donor [donorId=" + donorId + ", donorType=" + donorType + ", firstName=" + firstName + ", lastName="
				+ lastName + ", organizationName=" + organizationName + ", licenseNo=" + licenseNo + ", contactNo="
				+ contactNo + ", email=" + email + ", website=" + website + ", status=" + status + ", area=" + area
				+ ", user=" + user + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(area, contactNo, donorId, donorType, email, firstName, lastName, licenseNo,
				organizationName, status, user, website);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Donor other = (Donor) obj;
		return Objects.equals(area, other.area) && Objects.equals(contactNo, other.contactNo)
				&& Objects.equals(donorId, other.donorId) && donorType == other.donorType
				&& Objects.equals(email, other.email) && Objects.equals(firstName, other.firstName)
				&& Objects.equals(lastName, other.lastName) && Objects.equals(licenseNo, other.licenseNo)
				&& Objects.equals(organizationName, other.organizationName) && status == other.status
				&& Objects.equals(user, other.user) && Objects.equals(website, other.website);
	}

    // Getters and Setters

    // Constructors, equals, and hashCode methods
}
