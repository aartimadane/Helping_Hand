package com.example.demo.entity;

import java.sql.Date;
import java.util.Objects;
import java.util.Set;

import com.example.demo.entity.User.SeekerType;
import com.example.demo.entity.User.UserStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "seeker")
public class Seeker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "seeker_id")
    private Integer seekerId;

    @Column(name = "seeker_name", nullable = false)
    private String seekerName;

    @Enumerated(EnumType.STRING)
    @Column(name = "seeker_type", nullable = false)
    private SeekerType seekerType;

    @Column(name = "license_no", nullable = false, unique = true)
    private String licenseNo;

    @Column(name = "contact_no")
    private String contactNo;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "website")
    private String website;

    @Column(name = "records")
    private String records;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private UserStatus status;

    @ManyToOne
    @JoinColumn(name = "u_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "ngo_id")
    private NGO ngo;

    @Column(name = "foundation_date")
    private java.sql.Date foundationDate;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

	public Integer getSeekerId() {
		return seekerId;
	}

	public void setSeekerId(Integer seekerId) {
		this.seekerId = seekerId;
	}

	public String getSeekerName() {
		return seekerName;
	}

	public void setSeekerName(String seekerName) {
		this.seekerName = seekerName;
	}

	public SeekerType getSeekerType() {
		return seekerType;
	}

	public void setSeekerType(SeekerType seekerType) {
		this.seekerType = seekerType;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getRecords() {
		return records;
	}

	public void setRecords(String records) {
		this.records = records;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public NGO getNgo() {
		return ngo;
	}

	public void setNgo(NGO ngo) {
		this.ngo = ngo;
	}

	public java.sql.Date getFoundationDate() {
		return foundationDate;
	}

	public void setFoundationDate(java.sql.Date foundationDate) {
		this.foundationDate = foundationDate;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Seeker(Integer seekerId, String seekerName, SeekerType seekerType, String licenseNo, String contactNo,
			String email, String website, String records, UserStatus status, User user, NGO ngo, Date foundationDate,
			Area area) {
		super();
		this.seekerId = seekerId;
		this.seekerName = seekerName;
		this.seekerType = seekerType;
		this.licenseNo = licenseNo;
		this.contactNo = contactNo;
		this.email = email;
		this.website = website;
		this.records = records;
		this.status = status;
		this.user = user;
		this.ngo = ngo;
		this.foundationDate = foundationDate;
		this.area = area;
	}

	public Seeker() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Seeker [seekerId=" + seekerId + ", seekerName=" + seekerName + ", seekerType=" + seekerType
				+ ", licenseNo=" + licenseNo + ", contactNo=" + contactNo + ", email=" + email + ", website=" + website
				+ ", records=" + records + ", status=" + status + ", user=" + user + ", ngo=" + ngo
				+ ", foundationDate=" + foundationDate + ", area=" + area + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(area, contactNo, email, foundationDate, licenseNo, ngo, records, seekerId, seekerName,
				seekerType, status, user, website);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seeker other = (Seeker) obj;
		return Objects.equals(area, other.area) && Objects.equals(contactNo, other.contactNo)
				&& Objects.equals(email, other.email) && Objects.equals(foundationDate, other.foundationDate)
				&& Objects.equals(licenseNo, other.licenseNo) && Objects.equals(ngo, other.ngo)
				&& Objects.equals(records, other.records) && Objects.equals(seekerId, other.seekerId)
				&& Objects.equals(seekerName, other.seekerName) && seekerType == other.seekerType
				&& status == other.status && Objects.equals(user, other.user) && Objects.equals(website, other.website);
	}

    // Getters and Setters

    // Constructors, equals, and hashCode methods
}
