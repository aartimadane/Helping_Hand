package com.example.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Acknowledgement;
import com.example.demo.service.AcknowledgementService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/acknowledgements")
public class AcknowledgementController {

    @Autowired
    private AcknowledgementService aService;

    // Create or Update an Acknowledgement
    @PostMapping
    public Acknowledgement createOrUpdateAcknowledgement(@RequestBody Acknowledgement acknowledgement) {
        return aService.saveOrUpdateAcknowledgement(acknowledgement);
    }

    // Get all Acknowledgements
    @GetMapping
    public List<Acknowledgement> getAllAcknowledgements() {
        return aService.getAllAcknowledgements();
    }

    // Get an Acknowledgement by ID
    @GetMapping("/{id}")
    public ResponseEntity<Acknowledgement> getAcknowledgementById(@PathVariable int id) {
        Optional<Acknowledgement> acknowledgement = aService.getAcknowledgementById(id);
        return acknowledgement.map(ResponseEntity::ok)
                               .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete an Acknowledgement by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAcknowledgementById(@PathVariable int id) {
        Optional<Acknowledgement> acknowledgement = aService.getAcknowledgementById(id);
        if (acknowledgement.isPresent()) {
            aService.deleteAcknowledgementById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

