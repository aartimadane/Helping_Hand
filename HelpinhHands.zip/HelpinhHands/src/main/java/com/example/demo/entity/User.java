package com.example.demo.entity;

import java.sql.Timestamp;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;




@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "u_id")
    private Integer uId;

    @Column(name = "pwd", nullable = false)
    private String password;

    @Column(name = "u_name", nullable = false)
    private String username;

    @Column(name = "created_at")
    private java.sql.Timestamp createdAt;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;
    
    public enum UserStatus {
        Active,Inactive
    }


    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private UserStatus status;


    @OneToMany(mappedBy = "user")
    private Set<Donor> donors;

    @OneToMany(mappedBy = "user")
    private Set<NGO> ngos;

    @OneToMany(mappedBy = "user")
    private Set<Seeker> seekers;
    
    
   

    public enum DonorType {
        Single,Organization
    }

    public enum SeekerType {
        Individual,Organization
    }

	public Integer getuId() {
		return uId;
	}

	public void setuId(Integer uId) {
		this.uId = uId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public java.sql.Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(java.sql.Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}



	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public Set<Donor> getDonors() {
		return donors;
	}

	public void setDonors(Set<Donor> donors) {
		this.donors = donors;
	}

	public Set<NGO> getNgos() {
		return ngos;
	}

	public void setNgos(Set<NGO> ngos) {
		this.ngos = ngos;
	}

	public Set<Seeker> getSeekers() {
		return seekers;
	}

	public void setSeekers(Set<Seeker> seekers) {
		this.seekers = seekers;
	}

	

	public User(Integer uId, String password, String username, Timestamp createdAt, Area area, Role role,
			UserStatus status, Set<Donor> donors, Set<NGO> ngos, Set<Seeker> seekers) {
		super();
		this.uId = uId;
		this.password = password;
		this.username = username;
		this.createdAt = createdAt;
		this.area = area;
		this.role = role;
		this.status = status;
		this.donors = donors;
		this.ngos = ngos;
		this.seekers = seekers;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "User [uId=" + uId + ", password=" + password + ", username=" + username + ", createdAt=" + createdAt
				+ ", area=" + area + ", role=" + role + ", status=" + status + ", donors=" + donors + ", ngos=" + ngos
				+ ", seekers=" + seekers + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(area, createdAt, donors, ngos, password, role, seekers, status, uId, username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(area, other.area) && Objects.equals(createdAt, other.createdAt)
				&& Objects.equals(donors, other.donors) && Objects.equals(ngos, other.ngos)
				&& Objects.equals(password, other.password) && Objects.equals(role, other.role)
				&& Objects.equals(seekers, other.seekers) && status == other.status && Objects.equals(uId, other.uId)
				&& Objects.equals(username, other.username);
	}


    // Getters and Setters

    // Constructors, equals, and hashCode methods
}
