package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.DemoRequirement;
import com.example.demo.entity.Requirements;
import com.example.demo.repository.CategoryRepository;
import com.example.demo.repository.RequirementsRepository;
import com.example.demo.service.RequirementsService;

import java.util.List;

@RestController
@RequestMapping("/api/requirements")
@CrossOrigin
public class RequirementsController {

    @Autowired
    private RequirementsService requirementService;
    
    @Autowired
    RequirementsRepository repo;

    @GetMapping
    public List<Requirements> getAllRequirements() {
        return requirementService.getAllRequirements();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Requirements> getRequirementById(@PathVariable int id) {
        Requirements requirement = requirementService.getRequirementById(id);
        if (requirement == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(requirement);
    }

    @PostMapping
    public Requirements createRequirement(@RequestBody Requirements requirement) {
        return requirementService.saveRequirement(requirement);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Requirements> updateRequirement(@PathVariable int id, @RequestBody Requirements requirementDetails) {
        Requirements requirement = requirementService.getRequirementById(id);
        if (requirement == null) {
            return ResponseEntity.notFound().build();
        }

        requirement.setRequirementName(requirementDetails.getRequirementName());
        requirement.setRequirementDesc(requirementDetails.getRequirementDesc());
        requirement.setQuantity(requirementDetails.getQuantity());
        requirement.setCategoryId(requirementDetails.getCategoryId());
        requirement.setStatus(requirementDetails.getStatus());
        requirement.setDateNeededBy(requirementDetails.getDateNeededBy());
        requirement.setUserId(requirementDetails.getUserId());

        Requirements updatedRequirement = requirementService.saveRequirement(requirement);
        return ResponseEntity.ok(updatedRequirement);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRequirement(@PathVariable int id) {
        Requirements requirement = requirementService.getRequirementById(id);
        if (requirement == null) {
            return ResponseEntity.notFound().build();
        }

        requirementService.deleteRequirement(id);
        return ResponseEntity.noContent().build();
    }
    
    
    @Autowired
    CategoryRepository cat;
    
    
    @PostMapping("/addreq")
    public Requirements addReq(@RequestBody DemoRequirement demo) {
    	Requirements r= new Requirements();
    	r.setCategoryId(cat.findById(r.getCategoryId()).get().getCatId());
    	r.setRequirementDesc(demo.getReqdesc());
    	r.setRequirementName(demo.getReqname());
    	r.setDateNeededBy(demo.getNeedeby());
    	r.setQuantity(demo.getQuantity());
    	r.setDatePosted(demo.getDateposted());
    	r.setUserId(4);
    	return repo.save(r);
    }
    
    
}
