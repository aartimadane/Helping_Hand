package com.example.demo.controller;

import com.example.demo.entity.DemoForAmt;
import com.example.demo.entity.DonationForResources;
import com.example.demo.service.DonationForResourcesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping
@CrossOrigin
public class DonationForResourcesController {

    @Autowired
    private DonationForResourcesService donationForResourcesService;

    // Create a new donation
    @PostMapping
    public ResponseEntity<DonationForResources> createDonation(@RequestBody DonationForResources donationForResources) {
        DonationForResources createdDonation = donationForResourcesService.saveOrUpdateDonation(donationForResources);
        return ResponseEntity.ok(createdDonation);
    }

    // Get all donations
    @GetMapping("/api/donations/getAllResources")
    public ResponseEntity<List<DonationForResources>> getAllDonations() {
        List<DonationForResources> donations = donationForResourcesService.getAllDonations();
        return ResponseEntity.ok(donations);
    }

    // Get a donation by ID
    @GetMapping("/{id}")
    public ResponseEntity<DonationForResources> getDonationById(@PathVariable int id) {
        Optional<DonationForResources> donation = donationForResourcesService.getDonationById(id);
        return donation.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update an existing donation
    @PutMapping("/{id}")
    public ResponseEntity<DonationForResources> updateDonation(
            @PathVariable int id,
            @RequestBody DonationForResources donationForResources) {
        Optional<DonationForResources> existingDonation =      donationForResourcesService.getDonationById(id);
        if (existingDonation.isPresent()) {
            donationForResources.setDonationResourceId(id);  // Set the ID to the path variable ID
            DonationForResources updatedDonation = donationForResourcesService.saveOrUpdateDonation(donationForResources);
            return ResponseEntity.ok(updatedDonation);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete a donation by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDonation(@PathVariable int id) {
        Optional<DonationForResources> donation = donationForResourcesService.getDonationById(id);
        if (donation.isPresent()) {
            donationForResourcesService.deleteDonationById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PostMapping("/adddonationforresource")
    public DonationForResources addDonForRes(@RequestBody DemoForAmt d) {
    	return donationForResourcesService.addDoFRes(d);
    }
}
