package com.example.demo.repository;


import com.example.demo.entity.DonationForResources;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DonationForResourcesRepository extends JpaRepository<DonationForResources, Integer> {
}
