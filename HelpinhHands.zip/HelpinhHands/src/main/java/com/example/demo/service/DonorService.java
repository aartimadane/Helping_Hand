package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Donor;
import com.example.demo.entity.User;
import com.example.demo.repository.DonorRepository;

@Service
public class DonorService
{
	@Autowired
	DonorRepository drepo;
	
	public List<Donor> getAllDonors()
	{
		return drepo.findAll();
	}
	
}
