package com.example.demo.controller;

public class AddDonationController 
{
	//public List<DonationForResources> 
	
}
