package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.util.Objects;
import java.util.Set;

@Entity
@Table(name = "areas")
public class Area {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "area_id")
    private Integer areaId;

    @Column(name = "area_name", nullable = false)
    private String areaName;

    @ManyToOne
    @JoinColumn(name = "city_id")
    private City city;

	public Integer getAreaId() {
		return areaId;
	}

	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public Area(Integer areaId, String areaName, City city) {
		super();
		this.areaId = areaId;
		this.areaName = areaName;
		this.city = city;
	}

	public Area() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Area [areaId=" + areaId + ", areaName=" + areaName + ", city=" + city + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(areaId, areaName, city);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Area other = (Area) obj;
		return Objects.equals(areaId, other.areaId) && Objects.equals(areaName, other.areaName)
				&& Objects.equals(city, other.city);
	}

    // Getters and Setters
    

    // Constructors, equals, and hashCode methods
}
