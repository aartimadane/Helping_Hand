package com.example.demo.service;

import com.example.demo.entity.DemoForAmt;
import com.example.demo.entity.DonationForAmount;
import com.example.demo.repository.DonationForAmountRepository;
import com.example.demo.repository.RequirementsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DonationForAmountService {

    @Autowired
    DonationForAmountRepository donationForAmountRepository;
    
    @Autowired
    RequirementsRepository rrepo;

    // Create or Update a DonationForAmount
    public DonationForAmount saveOrUpdateDonationForAmount(DonationForAmount donationForAmount) {
        return donationForAmountRepository.save(donationForAmount);
    }

    // Get all DonationForAmounts
    public List<DonationForAmount> getAllDonationForAmounts() {
        return donationForAmountRepository.findAll();
    }

    // Get a DonationForAmount by ID
    public Optional<DonationForAmount> getDonationForAmountById(int id) {
        return donationForAmountRepository.findById(id);
    }

    // Delete a DonationForAmount by ID
    public void deleteDonationForAmountById(int id) {
        donationForAmountRepository.deleteById(id);
    }
    
    public DonationForAmount addDonForAmt(DemoForAmt d) {
    	DonationForAmount dfr= new DonationForAmount();
    	dfr.setAmount(d.getAmount());
    	dfr.setDate(d.getDate());
    	dfr.setRequirement(rrepo.findById(d.getRid()).get());
    	return donationForAmountRepository.save(dfr);
    }
    
}

