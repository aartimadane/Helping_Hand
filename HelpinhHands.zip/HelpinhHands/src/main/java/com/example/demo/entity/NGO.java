package com.example.demo.entity;

import java.sql.Date;
import java.util.Objects;
import java.util.Set;

import com.example.demo.entity.User.UserStatus;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;


@Entity
@Table(name = "ngo")
public class NGO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ngo_id")
    private Integer ngoId;

    @Column(name = "ngo_name", nullable = false)
    private String ngoName;

    @Column(name = "license_no", nullable = false, unique = true)
    private String licenseNo;

    @Column(name = "foundation_date")
    private java.sql.Date foundationDate;

    @Column(name = "owner", nullable = false)
    private String owner;

    @Column(name = "contact_no")
    private String contactNo;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Column(name = "website")
    private String website;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private UserStatus status;

    @ManyToOne
    @JoinColumn(name = "area_id")
    private Area area;

    @ManyToOne
    @JoinColumn(name = "u_id")
    private User user;

	public Integer getNgoId() {
		return ngoId;
	}

	public void setNgoId(Integer ngoId) {
		this.ngoId = ngoId;
	}

	public String getNgoName() {
		return ngoName;
	}

	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public java.sql.Date getFoundationDate() {
		return foundationDate;
	}

	public void setFoundationDate(java.sql.Date foundationDate) {
		this.foundationDate = foundationDate;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public NGO(Integer ngoId, String ngoName, String licenseNo, Date foundationDate, String owner, String contactNo,
			String email, String website, UserStatus status, Area area, User user) {
		super();
		this.ngoId = ngoId;
		this.ngoName = ngoName;
		this.licenseNo = licenseNo;
		this.foundationDate = foundationDate;
		this.owner = owner;
		this.contactNo = contactNo;
		this.email = email;
		this.website = website;
		this.status = status;
		this.area = area;
		this.user = user;
	}

	public NGO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "NGO [ngoId=" + ngoId + ", ngoName=" + ngoName + ", licenseNo=" + licenseNo + ", foundationDate="
				+ foundationDate + ", owner=" + owner + ", contactNo=" + contactNo + ", email=" + email + ", website="
				+ website + ", status=" + status + ", area=" + area + ", user=" + user + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(area, contactNo, email, foundationDate, licenseNo, ngoId, ngoName, owner, status, user,
				website);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NGO other = (NGO) obj;
		return Objects.equals(area, other.area) && Objects.equals(contactNo, other.contactNo)
				&& Objects.equals(email, other.email) && Objects.equals(foundationDate, other.foundationDate)
				&& Objects.equals(licenseNo, other.licenseNo) && Objects.equals(ngoId, other.ngoId)
				&& Objects.equals(ngoName, other.ngoName) && Objects.equals(owner, other.owner)
				&& status == other.status && Objects.equals(user, other.user) && Objects.equals(website, other.website);
	}



    // Getters and Setters

    // Constructors, equals, and hashCode methods
}
