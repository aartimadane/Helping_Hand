package com.example.demo.entity;

public class DemoDonor 
{
	
}
