package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.NGO;

public interface NGORepository extends JpaRepository<NGO,Integer> {

}
