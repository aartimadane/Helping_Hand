package com.example.demo.service;


import com.example.demo.entity.DemoForAmt;
import com.example.demo.entity.DonationForResources;
import com.example.demo.repository.DonationForResourcesRepository;
import com.example.demo.repository.RequirementsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DonationForResourcesService {

    @Autowired
    private DonationForResourcesRepository donationForResourcesRepository;
    
    @Autowired
    RequirementsRepository rrepo;

    // Create or update a donation
    public DonationForResources saveOrUpdateDonation(DonationForResources donationForResources) {
        return donationForResourcesRepository.save(donationForResources);
    }

    // Get all donations
    public List<DonationForResources> getAllDonations() {
        return donationForResourcesRepository.findAll();
    }

    // Get a donation by ID
    public Optional<DonationForResources> getDonationById(int id) {
        return donationForResourcesRepository.findById(id);
    }

    // Delete a donation by ID
    public void deleteDonationById(int id) {
        donationForResourcesRepository.deleteById(id);
    }
    
    public DonationForResources addDoFRes(DemoForAmt d) {
    	DonationForResources dfr= new DonationForResources();
    	dfr.setDate(d.getDate());
    	dfr.setDonationDesc(d.getDesc());
    	dfr.setRequirement(rrepo.findById(d.getRid()).get()	);
    	return donationForResourcesRepository.save(dfr);
    }
}

