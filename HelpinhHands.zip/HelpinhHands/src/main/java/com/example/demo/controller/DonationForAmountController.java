package com.example.demo.controller;

import com.example.demo.entity.DemoForAmt;
import com.example.demo.entity.DonationForAmount;
import com.example.demo.entity.Requirements;
import com.example.demo.service.DonationForAmountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.demo.service.RequirementsService;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
public class DonationForAmountController {

    @Autowired
    private DonationForAmountService donationForAmountService;

    // Create or Update a DonationForAmount
    @CrossOrigin
    @PostMapping("/api/donation")
    public DonationForAmount createOrUpdateDonationForAmount(@RequestBody DemoForAmt d) {
    
        return donationForAmountService.addDonForAmt(d);
     
    }

    // Get all DonationForAmounts
    @GetMapping("/api/donations")
    public List<DonationForAmount> getAllDonationForAmounts() {
        return donationForAmountService.getAllDonationForAmounts();
    }

    // Get a DonationForAmount by ID
    @GetMapping("/api/donations/{id}")
    public ResponseEntity<DonationForAmount> getDonationForAmountById(@PathVariable int id) {
        Optional<DonationForAmount> donationForAmount = donationForAmountService.getDonationForAmountById(id);
        return donationForAmount.map(ResponseEntity::ok)
                                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete a DonationForAmount by ID
    @DeleteMapping("/api/donations/{id}")
    public ResponseEntity<Void> deleteDonationForAmountById(@PathVariable int id) {
        Optional<DonationForAmount> donationForAmount = donationForAmountService.getDonationForAmountById(id);
        if (donationForAmount.isPresent()) {
            donationForAmountService.deleteDonationForAmountById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
