package com.example.demo.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Acknowledgement;
import com.example.demo.repository.AcknowledgementRepository;

import java.util.List;
import java.util.Optional;

@Service
public class AcknowledgementService {

    @Autowired
    private AcknowledgementRepository acknowledgementRepository;

    // Create or Update an Acknowledgement
    public Acknowledgement saveOrUpdateAcknowledgement(Acknowledgement acknowledgement) {
        return acknowledgementRepository.save(acknowledgement);
    }

    // Get all Acknowledgements
    public List<Acknowledgement> getAllAcknowledgements() {
        return acknowledgementRepository.findAll();
    }

    // Get an Acknowledgement by ID
    public Optional<Acknowledgement> getAcknowledgementById(int id) {
        return acknowledgementRepository.findById(id);
    }

    // Delete an Acknowledgement by ID
    public void deleteAcknowledgementById(int id) {
        acknowledgementRepository.deleteById(id);
    }
}

