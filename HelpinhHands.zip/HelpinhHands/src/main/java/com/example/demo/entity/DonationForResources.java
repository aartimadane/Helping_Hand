package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
@Setter
@Getter
@Entity
@Table(name = "donationforresources")
public class DonationForResources {

	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "donation_resource_id")
    private int donationResourceId;

    @Column(name = "date", columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
    private Timestamp date;

    @Column(name = "donation_desc", nullable = false, columnDefinition = "TEXT")
    private String donationDesc;

    @ManyToOne
    @JoinColumn(name = "requirement_id")
    private Requirements requirement;

    // Default constructor
    public DonationForResources() {
    }

    // Parameterized constructor
    public DonationForResources(Timestamp date, String donationDesc, Requirements requirement) {
        this.date = date;
        this.donationDesc = donationDesc;
        this.requirement = requirement;
    }

   
}
