package com.example.demo.entity;


import jakarta.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "acknowledgement")
public class Acknowledgement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Acknowledgement_id")
    private int acknowledgementId;

    @ManyToOne
    @JoinColumn(name = "donation_amt_id")
    private DonationForAmount donationForAmount;

    @ManyToOne
    @JoinColumn(name = "donation_resource_id")
    private DonationForResources donationForResources;
    	
    @Column(name = "Seeker_NGO", nullable = false)
    @Enumerated(EnumType.STRING)
    private SeekerNGO seekerNGO;

    @Column(name = "Date")
    private Date date;

    @ManyToOne
    @JoinColumn(name = "Donor_id")
    private Donor donor;

    // Default constructor
    public Acknowledgement() {
    }

    // Parameterized constructor
    public Acknowledgement(DonationForAmount donationForAmount, DonationForResources donationForResources, SeekerNGO seekerNGO, Date date, Donor donor) {
        this.donationForAmount = donationForAmount;
        this.donationForResources = donationForResources;
        this.seekerNGO = seekerNGO;
        this.date = date;
        this.donor = donor;
    }

    // Getters and Setters
    public int getAcknowledgementId() {
        return acknowledgementId;
    }

    public void setAcknowledgementId(int acknowledgementId) {
        this.acknowledgementId = acknowledgementId;
    }

    public DonationForAmount getDonationForAmount() {
        return donationForAmount;
    }

    public void setDonationForAmount(DonationForAmount donationForAmount) {
        this.donationForAmount = donationForAmount;
    }

    public DonationForResources getDonationForResources() {
        return donationForResources;
    }

    public void setDonationForResources(DonationForResources donationForResources) {
        this.donationForResources = donationForResources;
    }

    public SeekerNGO getSeekerNGO() {
        return seekerNGO;
    }

    public void setSeekerNGO(SeekerNGO seekerNGO) {
        this.seekerNGO = seekerNGO;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Donor getDonor() {
        return donor;
    }

    public void setDonor(Donor donor) {
        this.donor = donor;
    }

    @Override
    public String toString() {
        return "Acknowledgement{" +
                "acknowledgementId=" + acknowledgementId +
                ", donationForAmount=" + donationForAmount +
                ", donationForResources=" + donationForResources +
                ", seekerNGO=" + seekerNGO +
                ", date=" + date +
                ", donor=" + donor +
                '}';
    }

    public enum SeekerNGO {
        Seeker, NGO
    }
}


